# TradeFineX (Front-end Simulation)

This is a local-only demo of a trade finance app UI built with **Vite + React + Tailwind** and **lucide-react** icons. 
All actions are simulated with React state and `setTimeout` (no backend or blockchain).

## Quick Start

1. Install Node.js 18+
2. In a terminal:
   ```bash
   cd tradefinex
   npm install
   npm run dev
   ```
3. Open the URL shown (usually `http://localhost:5173`).

## Build for Production

```bash
npm run build
npm run preview
```

## Notes

- No real authentication, blockchain, IPFS or payments are performed.
- The UI allows switching roles (Exporter / Importer / Bank) to see permissioned views.
